const HouseInfo = {
    exists: {},
    owner: {},
    password: {},
    price: {},
    winperpayday: {},
    interior_id: {},
    exterior: {
        x: {},
        y: {},
        z: {}
    },
    interior: {
        x: {},
        y: {},
        z: {}
    },
    custom: {},
    Label3D: {},
    Pickup: {},
    MAX_HOUSES: 999
}
global.HouseInfo = HouseInfo;