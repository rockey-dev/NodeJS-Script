const FactionInfo = {
    Name: {},
    Spawn: {
        x: {},
        y: {},
        z: {}
    },
    Enter: {
        x: {},
        y: {},
        z: {}
    },
    Exit: {
        x: {},
        y: {},
        z: {}
    },
    Interior_Id: {},
    Skin_Id: {},
    Ranks: {
        _1_: {},
        _2_: {},
        _3_: {},
        _4_: {},
        _5_: {},
        _6_: {},
        _7_: {}
    }
}
global.FactionInfo = FactionInfo;