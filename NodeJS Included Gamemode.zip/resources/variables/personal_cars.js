const pCarInfo = {
    handle: {},
    owner: {},
    model: {},
    position: {
        x: {},
        y: {},
        z: {},
        a: {}
    },
    color1: {},
    color2: {},
    premium: {},
    texts: {
        /*slot1: {
            exists: {},
            object: {},
            text: {},
            coord: {
                OffSetX: {},
                OffSetY: {},
                OffSetZ: {},
                RotX: {},
                RotY: {},
                RotZ: {}
            }
        }*/
    },
    MAX_CARS: 999
}
global.pCarInfo = pCarInfo;