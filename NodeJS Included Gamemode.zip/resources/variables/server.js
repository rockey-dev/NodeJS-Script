const ServerInfo = {
    Location: {
        Return: {}
    }
}
global.ServerInfo = ServerInfo;