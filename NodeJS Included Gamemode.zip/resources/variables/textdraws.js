const TDInfo = {
    PlayerInfo: {}
}
global.TDInfo = TDInfo;