const colors = {
    DEFAULT: "A9C4E4",
    YELLOW: "FFD900",
    RED: "FF0000",
    GREEN: "00CC00"
}
global.colors = colors;

const colors2 = {
    DEFAULT: 0xA9C4E4AA,
    ORANGE: 0xFF5656AA
}
global.colors2 = colors2;